const express = require('express');
const parser=require('body-parser');
const mysql=require('mysql');
// const { response } = require('express');
// const { request } = require('http');
const app=express();

app.use(parser.json());

//create connection with database

const conn = mysql.createConnection({
    host:'localhost',
    user:'root',
    password: 'Admin@123',
    database:'world',
    insecureAuth:true
});

conn.connect((err)=>{
    if(err)
    throw err;
    console.log("connected to database...........");

});
// list thr order
app.get('/bajaj/persons',(request,response)=>{
    let sql = 'select* from persons';
    conn.query(sql,(err,result)=>{
        if(err)//if error is undefined then go to else
        throw err;//if error is not undefined then throw an error
        else{
            console.log(result);
            response.send(result);
        }
    });
});
app.post('/bajaj/persons',(request, response)=>{
    let data ={id:request.body.id, name:request.body.name, address:request.body.address, mobile:request.body.mobile, email:request.body.email, age:request.body.age, dateofbirth:request.body.dateofbirth};
    
    let sql ='insert into world.persons SET ?'; //JSON object field:value
    let query= conn.query(sql,data,(err,result)=>{
        if(err)
        throw err;
        else{
            console.log('persons details inserted successfully with an id'+result.insertid);
           
        }

    });
});

// app.put('bajaj/persons/:id',(request,response)=>{
//     let sql = 'update person set name=\''+request.body.name+'\',address='+request.body.address+'\',mobile='+request.body.mobile+'\',email='+request.body.email+'\',age='+request.body.age+'\',dateofbirth='+request.body.dateofbirth+' where id='+request.params.id;
//   let query = conn.query(sql,(err, result)=>{
//         if(err)
//         throw err;
//         else{
//             console.log('person details updated successfully....');
           
//         }

//     });
// });


//edit account details
app.put('/bajaj/persons/:id',(request,response)=>{
    let sql='update persons set name=\''+request.body.name+'\',address=\''+request.body.address+'\',mobile=\''+request.body.mobile+'\', email=\''+request.body.email+'\', age=\''+request.body.age+'\', dateofbirth=\''+request.body.dateofbirth+'\' where id='+request.params.id;
     
        let query=conn.query(sql,(err,result)=>{
            if(err)
                throw err;
            else if(result.affectedRows>0)
                response.send('Record Updated Successfully....');
     
        });
     
    });
     
    //DELETE person record by id
    app.delete('/bajaj/persons/:id',(request,response)=>{
        let sql="delete from persons where id="+request.params.id;
        letquery=conn.query(sql,(err,result)=>{
            if(err)
                throw err;
            response.send('Record Got Deleted Successfully....');
        });
     
    });
     
    // app.listen(3000,()=>{
    //     console.log('Server Started on port 3000......');
    // });


app.listen(4000);
